/* =========================================================
   Predictive Modeling Using Machine Learning — ML Engine
   Small, dependency-free implementations meant for teaching
   and demoing the pipeline end-to-end in the browser.
   ========================================================= */
const ML = (() => {

  // ---------- shared helpers ----------
  function mean(a){ return a.reduce((s,v)=>s+v,0)/a.length; }
  function variance(a){ const m=mean(a); return a.reduce((s,v)=>s+(v-m)*(v-m),0)/a.length; }
  function dot(a,b){ let s=0; for(let i=0;i<a.length;i++) s+=a[i]*b[i]; return s; }
  function shuffleIdx(n, seed){
    const idx = Array.from({length:n}, (_,i)=>i);
    let s = seed || 42;
    const rnd = () => { s = (s*1664525+1013904223) % 4294967296; return s/4294967296; };
    for(let i=idx.length-1;i>0;i--){ const j=Math.floor(rnd()*(i+1)); [idx[i],idx[j]]=[idx[j],idx[i]]; }
    return idx;
  }

  // ---------- Linear Regression (batch gradient descent) ----------
  function trainLinearRegression(X, y, opts={}){
    const lr = opts.lr ?? 0.08, epochs = opts.epochs ?? 250;
    const n = X.length, d = X[0].length;
    let w = new Array(d).fill(0), b = 0;
    for(let ep=0; ep<epochs; ep++){
      const gw = new Array(d).fill(0); let gb = 0;
      for(let i=0;i<n;i++){
        const pred = dot(X[i], w) + b;
        const err = pred - y[i];
        for(let j=0;j<d;j++) gw[j] += err * X[i][j];
        gb += err;
      }
      for(let j=0;j<d;j++) w[j] -= lr * (gw[j]/n);
      b -= lr * (gb/n);
      if(opts.onProgress && ep % Math.max(1,Math.floor(epochs/20))===0) opts.onProgress((ep+1)/epochs);
    }
    if(opts.onProgress) opts.onProgress(1);
    return {
      type:'linear', weights:w, bias:b,
      predict: (row) => dot(row, w) + b,
      importances: w.map(v=>Math.abs(v))
    };
  }

  // ---------- Logistic Regression (binary, gradient descent) ----------
  function sigmoid(z){ return 1/(1+Math.exp(-z)); }
  function trainLogisticRegression(X, y, opts={}){
    const lr = opts.lr ?? 0.15, epochs = opts.epochs ?? 300;
    const n = X.length, d = X[0].length;
    let w = new Array(d).fill(0), b = 0;
    for(let ep=0; ep<epochs; ep++){
      const gw = new Array(d).fill(0); let gb = 0;
      for(let i=0;i<n;i++){
        const pred = sigmoid(dot(X[i], w) + b);
        const err = pred - y[i];
        for(let j=0;j<d;j++) gw[j] += err * X[i][j];
        gb += err;
      }
      for(let j=0;j<d;j++) w[j] -= lr * (gw[j]/n);
      b -= lr * (gb/n);
      if(opts.onProgress && ep % Math.max(1,Math.floor(epochs/20))===0) opts.onProgress((ep+1)/epochs);
    }
    if(opts.onProgress) opts.onProgress(1);
    return {
      type:'logistic', weights:w, bias:b,
      predictProba: (row) => sigmoid(dot(row, w) + b),
      predict: (row) => sigmoid(dot(row, w) + b) >= 0.5 ? 1 : 0,
      importances: w.map(v=>Math.abs(v))
    };
  }

  // ---------- Decision Tree (CART) ----------
  function giniImpurity(labels){
    const counts = {};
    labels.forEach(l => counts[l] = (counts[l]||0)+1);
    let imp = 1;
    const n = labels.length;
    Object.values(counts).forEach(c => { const p=c/n; imp -= p*p; });
    return imp;
  }
  function majorityClass(labels){
    const counts = {};
    labels.forEach(l => counts[l] = (counts[l]||0)+1);
    let best=null, bestC=-1;
    Object.entries(counts).forEach(([k,c])=>{ if(c>bestC){bestC=c; best=k;} });
    return Number(best);
  }
  function positiveProba(labels){
    // fraction of samples in a leaf/node belonging to the "1" class (binary classification score)
    if(!labels.length) return 0;
    return labels.filter(l=>l===1).length / labels.length;
  }

  function buildTree(X, y, options){
    const { maxDepth, minSamplesSplit, taskType, nFeaturesToTry } = options;
    const nFeatures = X[0].length;

    function impurityOf(idxs){
      const labels = idxs.map(i=>y[i]);
      return taskType==='regression' ? variance(labels) : giniImpurity(labels);
    }
    function leafValue(idxs){
      const labels = idxs.map(i=>y[i]);
      return taskType==='regression' ? mean(labels) : majorityClass(labels);
    }
    function leafProba(idxs){
      return positiveProba(idxs.map(i=>y[i]));
    }

    const importances = new Array(nFeatures).fill(0);

    function recurse(idxs, depth){
      const labels = idxs.map(i=>y[i]);
      if(depth>=maxDepth || idxs.length<minSamplesSplit || new Set(labels).size===1){
        return { leaf:true, value:leafValue(idxs), proba:leafProba(idxs) };
      }
      const parentImpurity = impurityOf(idxs);
      let candidateFeatures = Array.from({length:nFeatures}, (_,i)=>i);
      if(nFeaturesToTry && nFeaturesToTry < nFeatures){
        candidateFeatures = candidateFeatures.sort(()=>Math.random()-0.5).slice(0, nFeaturesToTry);
      }

      let best = null;
      for(const f of candidateFeatures){
        const values = Array.from(new Set(idxs.map(i=>X[i][f]))).sort((a,b)=>a-b);
        if(values.length < 2) continue;
        const thresholds = [];
        const step = Math.max(1, Math.floor(values.length/12));
        for(let k=0;k<values.length-1;k+=step){
          thresholds.push((values[k]+values[k+1])/2);
        }
        for(const t of thresholds){
          const left = idxs.filter(i => X[i][f] <= t);
          const right = idxs.filter(i => X[i][f] > t);
          if(left.length===0 || right.length===0) continue;
          const wl = left.length/idxs.length, wr = right.length/idxs.length;
          const childImpurity = wl*impurityOf(left) + wr*impurityOf(right);
          const gain = parentImpurity - childImpurity;
          if(!best || gain > best.gain){ best = { gain, f, t, left, right }; }
        }
      }
      if(!best || best.gain <= 1e-9){ return { leaf:true, value:leafValue(idxs), proba:leafProba(idxs) }; }

      importances[best.f] += best.gain * idxs.length;
      return {
        leaf:false, feature:best.f, threshold:best.t,
        left: recurse(best.left, depth+1),
        right: recurse(best.right, depth+1)
      };
    }

    const root = recurse(Array.from({length:X.length},(_,i)=>i), 0);
    return { root, importances };
  }

  function treePredict(node, row){
    while(!node.leaf){ node = row[node.feature] <= node.threshold ? node.left : node.right; }
    return node.value;
  }
  function treePredictProba(node, row){
    while(!node.leaf){ node = row[node.feature] <= node.threshold ? node.left : node.right; }
    return node.proba;
  }

  function trainDecisionTree(X, y, opts={}){
    const taskType = opts.taskType || 'regression';
    const { root, importances } = buildTree(X, y, {
      maxDepth: opts.maxDepth ?? 6,
      minSamplesSplit: opts.minSamplesSplit ?? 4,
      taskType
    });
    if(opts.onProgress) opts.onProgress(1);
    const total = importances.reduce((s,v)=>s+v,0) || 1;
    return {
      type:'dtree', root, taskType,
      predict: (row) => treePredict(root, row),
      predictProba: taskType==='classification' ? (row)=>treePredictProba(root,row) : undefined,
      importances: importances.map(v=>v/total)
    };
  }

  // ---------- Random Forest ----------
  function trainRandomForest(X, y, opts={}){
    const taskType = opts.taskType || 'regression';
    const nTrees = opts.nTrees ?? 12;
    const maxDepth = opts.maxDepth ?? 6;
    const nFeatures = X[0].length;
    const nFeaturesToTry = Math.max(1, Math.round(Math.sqrt(nFeatures)));
    const trees = [];
    const importances = new Array(nFeatures).fill(0);

    for(let t=0; t<nTrees; t++){
      const n = X.length;
      const bootstrapIdx = Array.from({length:n}, ()=>Math.floor(Math.random()*n));
      const bx = bootstrapIdx.map(i=>X[i]);
      const by = bootstrapIdx.map(i=>y[i]);
      const { root, importances: imp } = buildTree(bx, by, {
        maxDepth, minSamplesSplit: opts.minSamplesSplit ?? 4, taskType, nFeaturesToTry
      });
      trees.push(root);
      imp.forEach((v,i)=>importances[i]+=v);
      if(opts.onProgress) opts.onProgress((t+1)/nTrees);
    }
    const total = importances.reduce((s,v)=>s+v,0) || 1;

    function predictRow(row){
      const preds = trees.map(root => treePredict(root, row));
      if(taskType==='regression') return mean(preds);
      const counts = {};
      preds.forEach(p => counts[p]=(counts[p]||0)+1);
      let best=null,bestC=-1;
      Object.entries(counts).forEach(([k,c])=>{ if(c>bestC){bestC=c;best=k;} });
      return Number(best);
    }
    function predictProbaRow(row){
      const probas = trees.map(root => treePredictProba(root, row));
      return mean(probas);
    }

    return {
      type:'rforest', trees, taskType,
      predict: predictRow,
      predictProba: taskType==='classification' ? predictProbaRow : undefined,
      importances: importances.map(v=>v/total)
    };
  }

  // ---------- Metrics ----------
  function accuracy(yTrue, yPred){
    let c=0; for(let i=0;i<yTrue.length;i++) if(yTrue[i]===yPred[i]) c++;
    return c/yTrue.length;
  }
  function precisionRecallF1(yTrue, yPred, classes){
    const per = {};
    classes.forEach(cls=>{
      let tp=0, fp=0, fn=0;
      for(let i=0;i<yTrue.length;i++){
        if(yPred[i]===cls && yTrue[i]===cls) tp++;
        else if(yPred[i]===cls && yTrue[i]!==cls) fp++;
        else if(yPred[i]!==cls && yTrue[i]===cls) fn++;
      }
      const precision = tp+fp===0 ? 0 : tp/(tp+fp);
      const recall = tp+fn===0 ? 0 : tp/(tp+fn);
      const f1 = precision+recall===0 ? 0 : 2*precision*recall/(precision+recall);
      per[cls] = { precision, recall, f1 };
    });
    const macro = (key) => classes.reduce((s,c)=>s+per[c][key],0)/classes.length;
    return { per, precision: macro('precision'), recall: macro('recall'), f1: macro('f1') };
  }
  function confusionMatrix(yTrue, yPred, classes){
    const m = classes.map(()=>classes.map(()=>0));
    const idx = new Map(classes.map((c,i)=>[c,i]));
    for(let i=0;i<yTrue.length;i++){ m[idx.get(yTrue[i])][idx.get(yPred[i])]++; }
    return m;
  }
  function rocCurve(yTrueBinary, scores){
    const thresholds = Array.from(new Set(scores)).sort((a,b)=>b-a);
    thresholds.unshift(1.01); thresholds.push(-0.01);
    const P = yTrueBinary.filter(v=>v===1).length || 1;
    const N = yTrueBinary.filter(v=>v===0).length || 1;
    const points = thresholds.map(t=>{
      let tp=0, fp=0;
      for(let i=0;i<scores.length;i++){
        if(scores[i] >= t){ if(yTrueBinary[i]===1) tp++; else fp++; }
      }
      return { fpr: fp/N, tpr: tp/P };
    });
    let auc = 0;
    for(let i=1;i<points.length;i++){
      auc += (points[i].fpr - points[i-1].fpr) * (points[i].tpr + points[i-1].tpr) / 2;
    }
    return { points, auc: Math.abs(auc) };
  }
  function mse(yTrue, yPred){
    let s=0; for(let i=0;i<yTrue.length;i++) s += (yTrue[i]-yPred[i])**2;
    return s/yTrue.length;
  }
  function r2Score(yTrue, yPred){
    const m = mean(yTrue);
    let ssRes=0, ssTot=0;
    for(let i=0;i<yTrue.length;i++){ ssRes += (yTrue[i]-yPred[i])**2; ssTot += (yTrue[i]-m)**2; }
    return ssTot===0 ? 0 : 1 - ssRes/ssTot;
  }

  return {
    trainLinearRegression, trainLogisticRegression, trainDecisionTree, trainRandomForest,
    accuracy, precisionRecallF1, confusionMatrix, rocCurve, mse, r2Score,
    mean, variance, shuffleIdx
  };
})();
