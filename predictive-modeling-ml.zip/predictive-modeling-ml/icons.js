/* Minimal hand-built line-icon set (no external icon font dependency). */
const ICONS = {
  home: '<path d="M4 11.5 12 5l8 6.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M6 10.5V19a1 1 0 0 0 1 1h3v-5h4v5h3a1 1 0 0 0 1-1v-8.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
  upload: '<path d="M12 15V4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M7.5 8.5 12 4l4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 15v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-3" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  sliders: '<path d="M4 6h9M17 6h3M4 12h3M9 12h11M4 18h13M19 18h1" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="13" cy="6" r="2" fill="currentColor"/><circle cx="7" cy="12" r="2" fill="currentColor"/><circle cx="17" cy="18" r="2" fill="currentColor"/>',
  cpu: '<rect x="7" y="7" width="10" height="10" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="10" y="10" width="4" height="4" rx="0.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M9 3v3M15 3v3M9 18v3M15 18v3M3 9h3M3 15h3M18 9h3M18 15h3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
  activity: '<path d="M3 12h4l2 7 4-14 2 7h6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>',
  target: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="0.9" fill="currentColor"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>',
  database: '<ellipse cx="12" cy="5.5" rx="8" ry="2.6" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4 5.5V18c0 1.4 3.6 2.6 8 2.6s8-1.2 8-2.6V5.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4 11.8c0 1.4 3.6 2.6 8 2.6s8-1.2 8-2.6" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  'check-circle': '<circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M8.5 12.3l2.4 2.4 4.6-5.2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
  'alert-triangle': '<path d="M12 4 22 20H2Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 10v4.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><circle cx="12" cy="17" r="0.9" fill="currentColor"/>'
};
function renderIcons(root){
  (root || document).querySelectorAll('i[data-icon]').forEach(el=>{
    const key = el.getAttribute('data-icon');
    if(ICONS[key] && !el.dataset.done){
      el.innerHTML = `<svg viewBox="0 0 24 24" width="100%" height="100%">${ICONS[key]}</svg>`;
      el.dataset.done = '1';
    }
  });
}
// This script tag sits at the end of <body>, so the DOM is already parsed —
// call immediately rather than waiting on an event that has already fired.
renderIcons();
