/* =========================================================
   Predictive Modeling Using Machine Learning — App Logic
   ========================================================= */
(() => {
  const MISSING_TOKENS = new Set(['', 'na', 'n/a', 'null', 'nan', '?', '-', 'none']);
  const MAX_TRAIN_ROWS = 3000; // keep the in-browser trainer responsive

  const S = { // ---- global app state ----
    raw: [], columns: [], dtypes: {}, missingCounts: {}, duplicateCount: 0,
    targetCol: null, featureCols: [],
    encodingMaps: {}, reverseMaps: {},
    scaling: 'none', scalingStats: {},
    taskType: null, classes: [],
    X: [], y: [], trainIdx: [], testIdx: [],
    testDisplayRows: [],
    modelType: null, model: null,
    yPredTest: [], yTrueTest: [],
    charts: {}
  };

  // ---------------------------- utilities ----------------------------
  function isMissing(v){ return v===null || v===undefined || MISSING_TOKENS.has(String(v).trim().toLowerCase()); }
  function isNumericToken(v){ if(isMissing(v)) return true; return v!=='' && !isNaN(Number(v)) && isFinite(Number(v)); }
  function fmt(n, d=3){ if(typeof n!=='number' || !isFinite(n)) return '—'; return Number(n.toFixed(d)).toString(); }
  function pct(n){ return (n*100).toFixed(1)+'%'; }
  function $(sel, root){ return (root||document).querySelector(sel); }
  function $all(sel, root){ return Array.from((root||document).querySelectorAll(sel)); }
  function el(tag, attrs={}, children=[]){
    const e = document.createElement(tag);
    Object.entries(attrs).forEach(([k,v])=>{
      if(k==='class') e.className = v;
      else if(k==='html') e.innerHTML = v;
      else if(k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    });
    (Array.isArray(children)?children:[children]).forEach(c=>{
      if(c===undefined||c===null) return;
      e.appendChild(typeof c==='string' ? document.createTextNode(c) : c);
    });
    return e;
  }
  function mulberry32(seed){
    return function(){
      seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
      let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // ---------------------------- routing ----------------------------
  const pageTitles = { home:'Home', upload:'Upload Dataset', preprocess:'Data Preprocessing', models:'Machine Learning Models', train:'Model Training & Testing', performance:'Model Performance Dashboard', predict:'Prediction' };
  function goto(page){
    $all('.page').forEach(p=>p.classList.remove('active'));
    const target = $('#page-'+page);
    if(target) target.classList.add('active');
    $all('.nav-item').forEach(b=>b.classList.toggle('active', b.dataset.page===page));
    $('#pageTitle').textContent = pageTitles[page] || page;
    closeSidebar();
    window.scrollTo({top:0, behavior:'smooth'});
    if(page==='preprocess') refreshPreprocessGate();
    if(page==='performance') refreshPerfGate();
    if(page==='predict') refreshPredictGate();
  }
  function closeSidebar(){ $('#sidebar').classList.remove('open'); $('#scrim').classList.remove('show'); }

  document.addEventListener('click', (e)=>{
    const navBtn = e.target.closest('.nav-item');
    if(navBtn){ goto(navBtn.dataset.page); return; }
    const gotoBtn = e.target.closest('[data-goto]');
    if(gotoBtn){ goto(gotoBtn.dataset.goto); return; }
  });
  $('#hamburger').addEventListener('click', ()=>{ $('#sidebar').classList.add('open'); $('#scrim').classList.add('show'); });
  $('#scrim').addEventListener('click', closeSidebar);

  // ---------------------------- HOME hero visual ----------------------------
  function drawHero(){
    const rnd = mulberry32(7);
    const pts = Array.from({length:16}, (_,i)=>{
      const x = 40 + i*(340/15);
      const y = 260 - (i*12 + (rnd()-0.5)*70);
      return { x, y: Math.max(40, Math.min(280,y)) };
    });
    const dotsG = $('#heroDots'), fitLine = $('#heroFit'), nodesG = $('#heroNodes');
    dotsG.innerHTML = ''; nodesG.innerHTML = '';
    pts.forEach(p=>{
      const c = document.createElementNS('http://www.w3.org/2000/svg','circle');
      c.setAttribute('cx',p.x); c.setAttribute('cy',p.y); c.setAttribute('r',3.2);
      c.setAttribute('fill','#8FA0BE'); c.setAttribute('opacity','.55');
      dotsG.appendChild(c);
    });
    const n = pts.length;
    const mx = pts.reduce((s,p)=>s+p.x,0)/n, my = pts.reduce((s,p)=>s+p.y,0)/n;
    let num=0, den=0;
    pts.forEach(p=>{ num += (p.x-mx)*(p.y-my); den += (p.x-mx)**2; });
    const slope = num/den, intercept = my - slope*mx;
    const x1=40, x2=380;
    fitLine.setAttribute('points', `${x1},${slope*x1+intercept} ${x2},${slope*x2+intercept}`);
    [ [90, slope*90+intercept], [230, slope*230+intercept], [340, slope*340+intercept] ].forEach(([x,y])=>{
      const c = document.createElementNS('http://www.w3.org/2000/svg','circle');
      c.setAttribute('cx',x); c.setAttribute('cy',y); c.setAttribute('r',6);
      c.setAttribute('fill','#F5A623');
      nodesG.appendChild(c);
    });
  }
  drawHero();

  // ---------------------------- SAMPLE DATASET ----------------------------
  function generateSampleDataset(){
    const rnd = mulberry32(2024);
    const contracts = ['Month-to-month','One year','Two year'];
    const internet = ['DSL','Fiber optic','No'];
    const rows = [];
    for(let i=0;i<180;i++){
      const age = Math.round(18 + rnd()*57);
      const tenure = Math.round(rnd()*72);
      const contract = contracts[Math.floor(rnd()*3)];
      const svc = internet[Math.floor(rnd()*3)];
      const charges = Math.round((20 + rnd()*100) * 100)/100;
      const tickets = Math.round(rnd()*rnd()*10);
      let score = -1.4;
      score += contract==='Month-to-month' ? 1.3 : contract==='One year' ? 0.1 : -0.9;
      score += (72-tenure)/72 * 1.6;
      score += (charges-60)/60 * 0.9;
      score += tickets/10 * 1.1;
      score += (rnd()-0.5)*1.6;
      const churn = 1/(1+Math.exp(-score)) > 0.5 ? 'Yes' : 'No';
      rows.push({
        CustomerAge: age, TenureMonths: tenure, MonthlyCharges: charges.toFixed(2),
        SupportTickets: tickets, ContractType: contract, InternetService: svc, Churn: churn
      });
    }
    // sprinkle missing values
    rows.forEach(r=>{
      if(rnd()<0.05) r.MonthlyCharges = '';
      if(rnd()<0.04) r.InternetService = '';
      if(rnd()<0.03) r.SupportTickets = '';
    });
    // add a handful of exact duplicates
    for(let i=0;i<5;i++) rows.push({...rows[Math.floor(rnd()*rows.length)]});
    return rows;
  }

  // ---------------------------- UPLOAD ----------------------------
  const dropzone = $('#dropzone'), fileInput = $('#fileInput');
  dropzone.addEventListener('click', ()=>fileInput.click());
  dropzone.addEventListener('dragover', e=>{ e.preventDefault(); dropzone.classList.add('dragover'); });
  dropzone.addEventListener('dragleave', ()=>dropzone.classList.remove('dragover'));
  dropzone.addEventListener('drop', e=>{
    e.preventDefault(); dropzone.classList.remove('dragover');
    if(e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', ()=>{ if(fileInput.files[0]) handleFile(fileInput.files[0]); });
  $('#loadSampleBtn').addEventListener('click', ()=>{
    $('#uploadFileName').textContent = 'Sample dataset loaded — Customer Churn (180 rows)';
    loadRows(generateSampleDataset());
  });

  function handleFile(file){
    $('#uploadFileName').textContent = file.name;
    Papa.parse(file, {
      header:true, skipEmptyLines:true,
      complete: (res)=> loadRows(res.data)
    });
  }

  function loadRows(rows){
    if(!rows || !rows.length){ alert('No rows found in that file.'); return; }
    resetDownstream(true);
    S.raw = rows;
    S.columns = Object.keys(rows[0]);
    profileData();
    renderUploadResults();
    populatePreprocessControls();
    $('#uploadResults').hidden = false;
    $('#rowsPill').hidden = false;
    $('#rowsPill').textContent = S.raw.length + ' rows';
    $('#statDataset').textContent = S.raw.length + ' × ' + S.columns.length;
  }

  function profileData(){
    S.dtypes = {}; S.missingCounts = {};
    S.columns.forEach(col=>{
      let missing = 0, numericOk = true;
      S.raw.forEach(r=>{
        const v = r[col];
        if(isMissing(v)) { missing++; return; }
        if(!isNumericToken(v)) numericOk = false;
      });
      S.dtypes[col] = numericOk ? 'numeric' : 'categorical';
      S.missingCounts[col] = missing;
    });
    const seen = new Set(); let dupes = 0;
    S.raw.forEach(r=>{
      const key = S.columns.map(c=>r[c]).join('␟');
      if(seen.has(key)) dupes++; else seen.add(key);
    });
    S.duplicateCount = dupes;
  }

  function renderUploadResults(){
    const totalMissing = Object.values(S.missingCounts).reduce((a,b)=>a+b,0);
    $('#statRows').textContent = S.raw.length;
    $('#statCols').textContent = S.columns.length;
    $('#statMissing').textContent = totalMissing;
    $('#statDupes').textContent = S.duplicateCount;

    const dtypeTable = $('#dtypeTable');
    dtypeTable.innerHTML = '';
    dtypeTable.appendChild(el('thead',{},[el('tr',{},[el('th',{},'Column'),el('th',{},'Type'),el('th',{},'Missing Values')])]));
    const tbody = el('tbody');
    S.columns.forEach(c=>{
      tbody.appendChild(el('tr',{},[
        el('td',{},c),
        el('td',{},[el('span',{class:'tag '+(S.dtypes[c]==='numeric'?'tag-num':'tag-cat')},S.dtypes[c])]),
        el('td',{},String(S.missingCounts[c]))
      ]));
    });
    dtypeTable.appendChild(tbody);

    const previewTable = $('#previewTable');
    previewTable.innerHTML = '';
    previewTable.appendChild(el('thead',{},[el('tr',{},S.columns.map(c=>el('th',{},c)))]));
    const pbody = el('tbody');
    S.raw.slice(0,10).forEach(r=>{
      pbody.appendChild(el('tr',{}, S.columns.map(c=>{
        const missing = isMissing(r[c]);
        return el('td',{class: missing?'miss':''}, missing?'missing':String(r[c]));
      })));
    });
    previewTable.appendChild(pbody);
    renderIcons();
  }

  // ---------------------------- PREPROCESSING ----------------------------
  function refreshPreprocessGate(){
    const has = S.raw.length>0;
    $('#preprocessGate').hidden = has;
    $('#preprocessBody').hidden = !has;
  }

  function populatePreprocessControls(){
    const targetSelect = $('#targetSelect');
    targetSelect.innerHTML = '';
    S.columns.forEach(c=> targetSelect.appendChild(el('option',{value:c}, c)));
    targetSelect.value = S.columns[S.columns.length-1];
    updateTargetHint();
    targetSelect.onchange = ()=>{ updateTargetHint(); renderFeatureChecks(); };
    renderFeatureChecks();
  }

  function updateTargetHint(){
    const t = $('#targetSelect').value;
    const type = S.dtypes[t];
    const uniq = new Set(S.raw.map(r=>r[t]).filter(v=>!isMissing(v))).size;
    $('#targetTypeHint').textContent = `Detected column type: ${type} · ${uniq} unique value${uniq===1?'':'s'}. ` +
      (type==='categorical' || uniq<=10 ? 'This looks like a classification target.' : 'This looks like a regression target.');
  }

  function renderFeatureChecks(){
    const target = $('#targetSelect').value;
    const grid = $('#featureChecks');
    grid.innerHTML = '';
    S.columns.forEach(c=>{
      if(c===target) return;
      const id = 'feat_'+c;
      const wrap = el('label',{class:'check-item', for:id},[
        el('input',{type:'checkbox', id, value:c, checked:'checked'}),
        el('span',{}, c + ' · ' + S.dtypes[c])
      ]);
      grid.appendChild(wrap);
    });
  }

  $('#splitRange').addEventListener('input', (e)=>{
    const test = Number(e.target.value);
    $('#splitReadout').textContent = `${100-test} / ${test}`;
  });

  $('#applyPreprocessBtn').addEventListener('click', applyPreprocessing);

  function applyPreprocessing(){
    const status = $('#preprocessStatus');
    try{
      const targetCol = $('#targetSelect').value;
      const featureCols = $all('#featureChecks input:checked').map(i=>i.value);
      if(!featureCols.length){ status.textContent = 'Select at least one feature column.'; return; }

      const missingStrategy = $all('input[name=missing]').find(r=>r.checked).value;
      const dedupe = $('#dedupeToggle').checked;
      const scaleMethod = $all('input[name=scale]').find(r=>r.checked).value;
      const usedCols = [targetCol, ...featureCols];

      // 1) work on a plain copy
      let rows = S.raw.map(r=>({...r}));

      // 2) missing values
      if(missingStrategy === 'drop'){
        rows = rows.filter(r => usedCols.every(c => !isMissing(r[c])));
      } else {
        usedCols.forEach(c=>{
          if(S.dtypes[c] === 'numeric'){
            const vals = rows.map(r=>r[c]).filter(v=>!isMissing(v)).map(Number);
            const m = vals.length ? ML.mean(vals) : 0;
            rows.forEach(r=>{ if(isMissing(r[c])) r[c] = m; });
          } else {
            const counts = {};
            rows.forEach(r=>{ if(!isMissing(r[c])) counts[r[c]] = (counts[r[c]]||0)+1; });
            let mode = Object.keys(counts)[0], best = -1;
            Object.entries(counts).forEach(([k,v])=>{ if(v>best){best=v; mode=k;} });
            rows.forEach(r=>{ if(isMissing(r[c])) r[c] = mode; });
          }
        });
      }

      // 3) de-duplicate
      if(dedupe){
        const seen = new Set(); const out = [];
        rows.forEach(r=>{
          const key = usedCols.map(c=>r[c]).join('␟');
          if(!seen.has(key)){ seen.add(key); out.push(r); }
        });
        rows = out;
      }

      if(rows.length < 10){ status.textContent = 'Not enough rows remain after cleaning — relax your settings.'; return; }

      // 4) encode categoricals
      S.encodingMaps = {}; S.reverseMaps = {};
      usedCols.forEach(c=>{
        if(S.dtypes[c] === 'categorical'){
          const uniq = Array.from(new Set(rows.map(r=>String(r[c])))).sort();
          const map = {}; const rev = {};
          uniq.forEach((v,i)=>{ map[v]=i; rev[i]=v; });
          S.encodingMaps[c] = map; S.reverseMaps[c] = rev;
        }
      });

      function encodedVal(c, v){
        return S.dtypes[c]==='categorical' ? S.encodingMaps[c][String(v)] : Number(v);
      }

      // 5) task type detection
      const targetUniq = Array.from(new Set(rows.map(r=>r[targetCol])));
      const isClassification = S.dtypes[targetCol]==='categorical' || targetUniq.length <= 10;
      S.taskType = isClassification ? 'classification' : 'regression';

      const yEncodedRaw = rows.map(r => encodedVal(targetCol, r[targetCol]));
      let yRaw;
      if(isClassification){
        // re-map to a canonical 0..k-1 code order so binary targets always land on {0,1}
        // (matters for numeric targets that weren't already 0/1-coded), and keep a
        // lookup back to the original label for display purposes.
        const uniqSorted = Array.from(new Set(yEncodedRaw)).sort((a,b)=>a-b);
        const codeMap = {}; const rev = {};
        uniqSorted.forEach((v,i)=>{
          codeMap[v] = i;
          rev[i] = S.dtypes[targetCol]==='categorical' ? S.reverseMaps[targetCol][v] : String(v);
        });
        yRaw = yEncodedRaw.map(v=>codeMap[v]);
        S.classes = uniqSorted.map((v,i)=>i);
        S.reverseMaps[targetCol] = rev;
      } else {
        yRaw = yEncodedRaw;
        S.classes = [];
      }

      let X = rows.map(r => featureCols.map(c => encodedVal(c, r[c])));

      // keep a human-readable copy (pre-scaling) for the prediction form / "fill sample"
      const displayRows = rows.map(r => {
        const o = {};
        featureCols.forEach(c => { o[c] = S.dtypes[c]==='categorical' ? String(r[c]) : Number(r[c]); });
        return o;
      });

      // 6) scaling (features only)
      S.scaling = scaleMethod;
      S.scalingStats = {};
      if(scaleMethod !== 'none'){
        featureCols.forEach((c, j)=>{
          const col = X.map(row=>row[j]);
          if(scaleMethod==='minmax'){
            const min = Math.min(...col), max = Math.max(...col);
            S.scalingStats[c] = { min, max };
          } else {
            const m = ML.mean(col), sd = Math.sqrt(ML.variance(col)) || 1;
            S.scalingStats[c] = { mean:m, std:sd };
          }
        });
        X = X.map(row => row.map((v,j)=>{
          const c = featureCols[j], st = S.scalingStats[c];
          return scaleMethod==='minmax' ? (st.max===st.min?0:(v-st.min)/(st.max-st.min)) : (v-st.mean)/st.std;
        }));
      }

      // 7) cap size for performance, then split
      let idxAll = ML.shuffleIdx(X.length, 42);
      if(idxAll.length > MAX_TRAIN_ROWS) idxAll = idxAll.slice(0, MAX_TRAIN_ROWS);
      const testFrac = Number($('#splitRange').value)/100;
      const nTest = Math.max(5, Math.round(idxAll.length*testFrac));
      const testIdx = idxAll.slice(0, nTest);
      const trainIdx = idxAll.slice(nTest);

      S.targetCol = targetCol; S.featureCols = featureCols;
      S.X = X; S.y = yRaw; S.trainIdx = trainIdx; S.testIdx = testIdx;
      S.testDisplayRows = testIdx.map(i => displayRows[i]);
      S.processedRowsPreview = idxAll.slice(0,10).map(i=>{
        const o = {};
        featureCols.forEach((c,j)=> o[c] = fmt(X[i][j],3));
        o[targetCol] = isClassification ? S.reverseMaps[targetCol][yRaw[i]] : fmt(yRaw[i],3);
        return o;
      });

      renderPreprocessSummary();
      updateModelAvailability();
      resetDownstream(false);

      $('#statTarget').textContent = targetCol;
      const sampledNote = (rows.length > MAX_TRAIN_ROWS) ? ` (sampled ${MAX_TRAIN_ROWS} of ${rows.length} rows for in-browser training)` : '';
      status.textContent = `Applied · ${new Date().toLocaleTimeString()}${sampledNote}`;
    } catch(err){
      console.error(err);
      status.textContent = 'Something went wrong — check your column selections.';
    }
  }

  function renderPreprocessSummary(){
    $('#preprocessSummaryPanel').hidden = false;
    $('#ppFinalRows').textContent = S.trainIdx.length + S.testIdx.length;
    $('#ppFeatures').textContent = S.featureCols.length;
    $('#ppTrain').textContent = S.trainIdx.length;
    $('#ppTest').textContent = S.testIdx.length;

    const table = $('#processedTable');
    table.innerHTML = '';
    const cols = [...S.featureCols, S.targetCol];
    table.appendChild(el('thead',{},[el('tr',{}, cols.map(c=>el('th',{}, c===S.targetCol? c+' (target)':c)))]));
    const tbody = el('tbody');
    S.processedRowsPreview.forEach(r=>{
      tbody.appendChild(el('tr',{}, cols.map(c=>el('td',{}, String(r[c])))));
    });
    table.appendChild(tbody);
  }

  // ---------------------------- MODELS ----------------------------
  const MODEL_LABELS = { linear:'Linear Regression', logistic:'Logistic Regression', dtree:'Decision Tree', rforest:'Random Forest' };

  function updateModelAvailability(){
    const cards = $all('.model-card');
    let firstEnabled = null;
    cards.forEach(card=>{
      const m = card.dataset.model;
      let enabled = true;
      if(!S.taskType) enabled = false;
      else if(m==='linear') enabled = S.taskType==='regression';
      else if(m==='logistic') enabled = S.taskType==='classification' && S.classes.length===2;
      card.classList.toggle('disabled', !enabled);
      card.querySelector('input').disabled = !enabled;
      if(enabled && !firstEnabled) firstEnabled = m;
    });
    if(firstEnabled){
      const radio = document.querySelector(`.model-card[data-model="${firstEnabled}"] input`);
      radio.checked = true;
      S.modelType = firstEnabled;
    }
    const hint = $('#modelHint');
    if(!S.taskType){
      hint.textContent = 'Complete preprocessing to see which models fit your target.';
    } else {
      hint.textContent = `Detected task: ${S.taskType==='classification' ? `classification (${S.classes.length} classes)` : 'regression'}. ` +
        (S.taskType==='classification' && S.classes.length!==2 ? 'Logistic Regression needs a binary target, so it is disabled for this dataset. ' : '') +
        'Decision Tree and Random Forest work for either task.';
    }
    updateStatusModel();
    renderHyperparamUI();
  }

  document.addEventListener('change', (e)=>{
    if(e.target.name === 'modelChoice'){
      S.modelType = e.target.value;
      updateStatusModel();
      renderHyperparamUI();
    }
  });

  function updateStatusModel(){ $('#statModel').textContent = S.modelType ? MODEL_LABELS[S.modelType] : '—'; }

  // ---------------------------- TRAIN ----------------------------
  function renderHyperparamUI(){
    const grid = $('#hyperparamGrid');
    grid.innerHTML = '';
    if(!S.modelType) return;
    if(S.modelType==='linear' || S.modelType==='logistic'){
      grid.appendChild(hyperCard('lrRate','Learning rate', 1, 40, 8, v=>(v/100).toFixed(2)));
      grid.appendChild(hyperCard('lrEpochs','Training epochs', 50, 500, 250, v=>String(v)));
    } else if(S.modelType==='dtree'){
      grid.appendChild(hyperCard('dtDepth','Max depth', 2, 14, 6, v=>String(v)));
      grid.appendChild(hyperCard('dtMin','Min samples to split', 2, 20, 4, v=>String(v)));
    } else if(S.modelType==='rforest'){
      grid.appendChild(hyperCard('rfTrees','Number of trees', 4, 40, 12, v=>String(v)));
      grid.appendChild(hyperCard('rfDepth','Max depth per tree', 2, 12, 6, v=>String(v)));
    }
  }
  function hyperCard(id, label, min, max, val, format){
    const valueEl = el('span',{class:'hv'}, format(val));
    const input = el('input',{type:'range', id, min:String(min), max:String(max), value:String(val)});
    input.addEventListener('input', ()=> valueEl.textContent = format(Number(input.value)));
    return el('div',{class:'hyper-card'},[
      el('label',{}, [label+': ', valueEl]),
      input
    ]);
  }
  function hyperVal(id){ const i = $('#'+id); return i ? Number(i.value) : undefined; }

  $('#trainBtn').addEventListener('click', startTraining);

  function startTraining(){
    if(!S.X.length){ alert('Apply preprocessing before training.'); return; }
    if(!S.modelType){ alert('Choose a model on the Models page first.'); return; }

    $('#trainBtn').disabled = true;
    $('#progressWrap').hidden = false;
    $('#trainResults').hidden = true;
    const fill = $('#progressFill'), label = $('#progressLabel');
    fill.style.width = '0%';
    label.textContent = `Preparing ${MODEL_LABELS[S.modelType]}…`;

    // yield one frame so the "preparing" state actually paints before the
    // (synchronous) training run blocks the main thread
    setTimeout(runTrainingNow, 30);
  }

  function runTrainingNow(){
    const fill = $('#progressFill'), label = $('#progressLabel');
    const trainX = S.trainIdx.map(i=>S.X[i]);
    const trainY = S.trainIdx.map(i=>S.y[i]);
    const testX = S.testIdx.map(i=>S.X[i]);
    const testY = S.testIdx.map(i=>S.y[i]);

    let model;
    if(S.modelType==='linear'){
      model = ML.trainLinearRegression(trainX, trainY, { lr: hyperVal('lrRate')/100, epochs: hyperVal('lrEpochs') });
    } else if(S.modelType==='logistic'){
      model = ML.trainLogisticRegression(trainX, trainY, { lr: hyperVal('lrRate')/100, epochs: hyperVal('lrEpochs') });
    } else if(S.modelType==='dtree'){
      model = ML.trainDecisionTree(trainX, trainY, { taskType:S.taskType, maxDepth: hyperVal('dtDepth'), minSamplesSplit: hyperVal('dtMin') });
    } else {
      model = ML.trainRandomForest(trainX, trainY, { taskType:S.taskType, nTrees: hyperVal('rfTrees'), maxDepth: hyperVal('rfDepth') });
    }

    const yPredTest = testX.map(row => model.predict(row));

    // cosmetic animated progress so the training step feels tangible
    let step = 0; const steps = 22;
    const timer = setInterval(()=>{
      step++;
      const p = Math.min(1, step/steps);
      fill.style.width = (p*100).toFixed(0)+'%';
      label.textContent = p<1 ? `Training ${MODEL_LABELS[S.modelType]}… ${(p*100).toFixed(0)}%` : 'Done';
      if(p>=1){
        clearInterval(timer);
        S.model = model; S.yPredTest = yPredTest; S.yTrueTest = testY;
        finishTraining();
      }
    }, 40);
  }

  function finishTraining(){
    $('#trainBtn').disabled = false;
    $('#trainResults').hidden = false;
    $('#trAlgo').textContent = MODEL_LABELS[S.modelType];
    $('#trTask').textContent = S.taskType;
    $('#trTrainN').textContent = S.trainIdx.length;
    $('#trTestN').textContent = S.testIdx.length;
    $('#taskPill').hidden = false;
    $('#taskPill').textContent = S.taskType==='classification' ? 'Classification' : 'Regression';

    const table = $('#samplePredTable');
    table.innerHTML = '';
    table.appendChild(el('thead',{},[el('tr',{},[el('th',{},'#'), el('th',{},'Actual'), el('th',{},'Predicted')])]));
    const tbody = el('tbody');
    for(let i=0;i<Math.min(8,S.testIdx.length);i++){
      const decode = (v)=> S.taskType==='classification' ? S.reverseMaps[S.targetCol][v] : fmt(v,2);
      tbody.appendChild(el('tr',{},[
        el('td',{}, String(i+1)),
        el('td',{}, decode(S.yTrueTest[i])),
        el('td',{}, decode(S.yPredTest[i]))
      ]));
    }
    table.appendChild(tbody);
    computePerformance();
    buildPredictForm();
  }

  // ---------------------------- PERFORMANCE ----------------------------
  function refreshPerfGate(){
    const has = !!S.model;
    $('#perfGate').hidden = has;
    $('#perfBody').hidden = !has;
  }

  function metricCard(container, label, value, cls){
    container.appendChild(el('div',{class:'metric-chip'+(cls?' '+cls:'')},[
      el('span',{}, label), el('b',{}, value)
    ]));
  }

  function computePerformance(){
    const cards = $('#metricCards');
    cards.innerHTML = '';
    $('#confMatrixPanel').hidden = true; $('#rocPanel').hidden = true; $('#avpPanel').hidden = true;

    if(S.taskType==='classification'){
      $('#perfSubtitle').textContent = 'Classification metrics on the held-out test set.';
      const acc = ML.accuracy(S.yTrueTest, S.yPredTest);
      const prf = ML.precisionRecallF1(S.yTrueTest, S.yPredTest, S.classes);
      metricCard(cards, 'Accuracy', pct(acc), acc>0.75?'good':(acc<0.5?'bad':''));
      metricCard(cards, 'Precision', pct(prf.precision));
      metricCard(cards, 'Recall', pct(prf.recall));
      metricCard(cards, 'F1 Score', pct(prf.f1));

      $('#confMatrixPanel').hidden = false;
      renderConfusionMatrix();

      if(S.classes.length===2 && S.model.predictProba){
        const testX = S.testIdx.map(i=>S.X[i]);
        const scores = testX.map(row=>S.model.predictProba(row));
        const yBin = S.yTrueTest.map(v=>v===S.classes[1]?1:0);
        const roc = ML.rocCurve(yBin, scores);
        $('#rocPanel').hidden = false;
        $('#aucLabel').textContent = `AUC = ${fmt(roc.auc,3)}`;
        renderRocChart(roc.points);
      }
    } else {
      $('#perfSubtitle').textContent = 'Regression metrics on the held-out test set.';
      const mseV = ML.mse(S.yTrueTest, S.yPredTest);
      const r2 = ML.r2Score(S.yTrueTest, S.yPredTest);
      metricCard(cards, 'Mean Squared Error', fmt(mseV,3));
      metricCard(cards, 'Root MSE', fmt(Math.sqrt(mseV),3));
      metricCard(cards, 'R² Score', fmt(r2,3), r2>0.6?'good':(r2<0?'bad':''));
      metricCard(cards, 'Test Samples', String(S.yTrueTest.length));

      $('#avpPanel').hidden = false;
      renderAvpChart();
    }
    renderFeatureImportance();
  }

  function renderConfusionMatrix(){
    const m = ML.confusionMatrix(S.yTrueTest, S.yPredTest, S.classes);
    const labels = S.classes.map(c=>S.reverseMaps[S.targetCol][c]);
    const max = Math.max(1, ...m.flat());
    const box = $('#confMatrix');
    box.innerHTML = '';
    const header = el('div',{class:'conf-row'},[el('div',{class:'conf-label'},'')]);
    labels.forEach(l=>header.appendChild(el('div',{class:'conf-label'}, 'Pred: '+l)));
    box.appendChild(header);
    m.forEach((row,i)=>{
      const rowEl = el('div',{class:'conf-row'},[el('div',{class:'conf-label'}, 'Actual: '+labels[i])]);
      row.forEach((v,j)=>{
        const diag = i===j;
        const opacity = 0.25 + 0.75*(v/max);
        const bg = diag ? `rgba(52,211,153,${opacity})` : `rgba(248,113,122,${opacity})`;
        rowEl.appendChild(el('div',{class:'conf-cell', style:`background:${bg}; color:#0B1120`},[
          el('span',{}, String(v))
        ]));
      });
      box.appendChild(rowEl);
    });
  }

  function destroyChart(key){ if(S.charts[key]){ S.charts[key].destroy(); delete S.charts[key]; } }

  function chartTheme(){
    return { text:'#93A2C1', grid:'rgba(37,49,80,.6)', accent:'#22D3C7', accent2:'#F5A623' };
  }

  function renderRocChart(points){
    destroyChart('roc');
    const t = chartTheme();
    S.charts.roc = new Chart($('#rocChart'), {
      type:'line',
      data:{ datasets:[
        { label:'ROC curve', data: points.map(p=>({x:p.fpr,y:p.tpr})), borderColor:t.accent, backgroundColor:'transparent', pointRadius:0, borderWidth:2, tension:0 },
        { label:'Random baseline', data:[{x:0,y:0},{x:1,y:1}], borderColor:t.text, borderDash:[5,5], pointRadius:0, borderWidth:1 }
      ]},
      options:{
        responsive:true, animation:{duration:400},
        scales:{
          x:{ min:0, max:1, title:{display:true, text:'False Positive Rate', color:t.text}, ticks:{color:t.text}, grid:{color:t.grid} },
          y:{ min:0, max:1, title:{display:true, text:'True Positive Rate', color:t.text}, ticks:{color:t.text}, grid:{color:t.grid} }
        },
        plugins:{ legend:{ labels:{ color:t.text } } }
      }
    });
  }

  function renderAvpChart(){
    destroyChart('avp');
    const t = chartTheme();
    const lo = Math.min(...S.yTrueTest, ...S.yPredTest), hi = Math.max(...S.yTrueTest, ...S.yPredTest);
    S.charts.avp = new Chart($('#avpChart'), {
      type:'scatter',
      data:{ datasets:[
        { label:'Test predictions', data: S.yTrueTest.map((v,i)=>({x:v,y:S.yPredTest[i]})), backgroundColor:t.accent2 },
        { label:'Perfect prediction', data:[{x:lo,y:lo},{x:hi,y:hi}], type:'line', borderColor:t.text, borderDash:[5,5], pointRadius:0, borderWidth:1 }
      ]},
      options:{
        responsive:true, animation:{duration:400},
        scales:{
          x:{ title:{display:true, text:'Actual', color:t.text}, ticks:{color:t.text}, grid:{color:t.grid} },
          y:{ title:{display:true, text:'Predicted', color:t.text}, ticks:{color:t.text}, grid:{color:t.grid} }
        },
        plugins:{ legend:{ labels:{ color:t.text } } }
      }
    });
  }

  function renderFeatureImportance(){
    destroyChart('fi');
    const t = chartTheme();
    const pairs = S.featureCols.map((f,i)=>({f, v:S.model.importances[i]||0})).sort((a,b)=>b.v-a.v);
    S.charts.fi = new Chart($('#fiChart'), {
      type:'bar',
      data:{ labels: pairs.map(p=>p.f), datasets:[{ label:'Relative importance', data: pairs.map(p=>p.v), backgroundColor:t.accent }] },
      options:{
        indexAxis:'y', responsive:true, animation:{duration:400},
        scales:{ x:{ ticks:{color:t.text}, grid:{color:t.grid} }, y:{ ticks:{color:t.text}, grid:{color:'transparent'} } },
        plugins:{ legend:{ display:false } }
      }
    });
  }

  // ---------------------------- PREDICT ----------------------------
  function refreshPredictGate(){
    const has = !!S.model;
    $('#predictGate').hidden = has;
    $('#predictBody').hidden = !has;
  }

  function buildPredictForm(){
    const form = $('#predictForm');
    form.innerHTML = '';
    S.featureCols.forEach(c=>{
      const id = 'pf_'+c;
      let control;
      if(S.dtypes[c]==='categorical'){
        control = el('select',{id, name:c});
        Object.keys(S.encodingMaps[c]).forEach(v=> control.appendChild(el('option',{value:v}, v)));
      } else {
        const vals = S.testDisplayRows.map(r=>r[c]);
        const avg = vals.length ? ML.mean(vals) : 0;
        control = el('input',{id, name:c, type:'number', step:'any', value: fmt(avg,2)});
      }
      form.appendChild(el('div',{class:'field'},[ el('label',{for:id}, c), control ]));
    });
    $('#predictResultPanel').hidden = true;
  }

  $('#fillSampleBtn').addEventListener('click', ()=>{
    if(!S.testDisplayRows.length) return;
    const row = S.testDisplayRows[Math.floor(Math.random()*S.testDisplayRows.length)];
    S.featureCols.forEach(c=>{ const input = $('#pf_'+c); if(input) input.value = row[c]; });
  });

  $('#predictForm').addEventListener('submit', (e)=>{
    e.preventDefault();
    if(!S.model) return;
    const row = S.featureCols.map(c=>{
      const raw = $('#pf_'+c).value;
      const encoded = S.dtypes[c]==='categorical' ? S.encodingMaps[c][raw] : Number(raw);
      if(S.scaling==='none') return encoded;
      const st = S.scalingStats[c];
      return S.scaling==='minmax' ? (st.max===st.min?0:(encoded-st.min)/(st.max-st.min)) : (encoded-st.mean)/st.std;
    });
    const pred = S.model.predict(row);
    $('#predictResultPanel').hidden = false;
    const resultBox = $('#predictResult');
    resultBox.innerHTML = '';

    if(S.taskType==='classification'){
      const label = S.reverseMaps[S.targetCol][pred];
      const isPositive = S.classes.length===2 && pred===S.classes[1];
      resultBox.appendChild(el('div',{class:'predict-badge '+(isPositive?'pos':'neg')}, label));
      resultBox.appendChild(el('span',{class:'rl'}, `Predicted ${S.targetCol}`));
      if(S.model.predictProba && S.classes.length===2){
        const p1 = S.model.predictProba(row);
        renderProbChart([1-p1, p1], [S.reverseMaps[S.targetCol][S.classes[0]], S.reverseMaps[S.targetCol][S.classes[1]]]);
      } else { destroyChart('prob'); }
    } else {
      resultBox.appendChild(el('span',{class:'rv'}, fmt(pred,3)));
      resultBox.appendChild(el('span',{class:'rl'}, `Predicted ${S.targetCol}`));
      destroyChart('prob');
    }
  });

  function renderProbChart(probs, labels){
    destroyChart('prob');
    const t = chartTheme();
    S.charts.prob = new Chart($('#probChart'), {
      type:'bar',
      data:{ labels, datasets:[{ data: probs.map(p=>+(p*100).toFixed(1)), backgroundColor:[t.text, t.accent2] }] },
      options:{
        indexAxis:'y', responsive:true, animation:{duration:400},
        scales:{ x:{ min:0, max:100, ticks:{color:t.text, callback:v=>v+'%'}, grid:{color:t.grid} }, y:{ ticks:{color:t.text}, grid:{color:'transparent'} } },
        plugins:{ legend:{ display:false }, tooltip:{ callbacks:{ label: c => c.raw+'% probability' } } }
      }
    });
  }

  // ---------------------------- RESET HELPERS ----------------------------
  function resetDownstream(fullReset){
    S.model = null; S.modelType = null;
    $('#trainResults').hidden = true;
    $('#taskPill').hidden = true;
    $('#statModel').textContent = '—';
    if(fullReset){
      S.taskType = null; S.classes = [];
      $('#statTarget').textContent = '—';
      $('#preprocessSummaryPanel').hidden = true;
    }
  }

  // ---------------------------- INIT ----------------------------
  goto('home');
})();
